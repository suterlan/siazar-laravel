<!-- Back to Top -->
    <a href="#" class="btn btn-primary p-3 back-to-top"
      ><i class="fa fa-angle-double-up"></i
    ></a>

    <!-- JavaScript Libraries -->
    <script src="{{ asset('') }}front/lib/jquery/jquery-3.4.1.min.js"></script>
    <script src="{{ asset('') }}front/lib/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="{{ asset('') }}front/lib/easing/easing.min.js"></script>
    <script src="{{ asset('') }}front/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="{{ asset('') }}front/lib/isotope/isotope.pkgd.min.js"></script>
    <script src="{{ asset('') }}front/lib/lightbox/js/lightbox.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="{{ asset('') }}front/mail/jqBootstrapValidation.min.js"></script>
    {{-- <script src="{{ asset('') }}front/mail/contact.js"></script> --}}

    <!-- Template Javascript -->
    <script src="{{ asset('') }}front/js/main.js"></script>
